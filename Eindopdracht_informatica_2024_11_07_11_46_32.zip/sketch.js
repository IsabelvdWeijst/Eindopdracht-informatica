class Raster {
  constructor(r,k) {
    this.aantalRijen = r;
    this.aantalKolommen = k;
    this.celGrootte = null;
  }
  
  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }
  
  teken() {
    push();
    noFill();
    stroke('grey');
    for (var rij = 0;rij < this.aantalRijen;rij++) {
      for (var kolom = 0;kolom < this.aantalKolommen;kolom++) {
   if (rij == 5 || kolom == 9) {
           if (floor(eve.y / this.celGrootte) == rij && floor(eve.x / this.celGrootte) == kolom) {
            fill('darkblue'); 
          } else {
            fill('lightpink'); 
          }
        } else {
          noFill(); 
        }
        rect(kolom * this.celGrootte, rij * this.celGrootte, this.celGrootte, this.celGrootte);
      }
    }
    pop();
  }
}



class Jos {
  constructor() {
    this.x = 400;
    this.y = 300;
    this.animatie = [];
    this.frameNummer =  3;
    this.stapGrootte = null;
    this.gehaald = false;
    this.levens = 1; //aantal levens om mee te beginnen
  }
  
  beweeg() {
    if (keyIsDown(65)) {
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) {
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) {
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) {
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }
    
    this.x = constrain(this.x,0,canvas.width);
    this.y = constrain(this.y,0,canvas.height - raster.celGrootte);
    
    if (this.x == canvas.width) {
      this.gehaald = true;
    }
  }
  
 wordtGeraakt(vijand) {
    const marge = 0.5 * raster.celGrootte; // Stel een marge in die de celgrootte halveert omdat bij te snel bewegende bommen er anders niet een leven afgaat
    const spelerCelX = this.x;
    const spelerCelY = this.y;
    const vijandCelX = vijand.x;
    const vijandCelY = vijand.y;

    // Controleer of de bom zich binnen de marge van de speler bevindt
    return abs(spelerCelX - vijandCelX) <= marge && abs(spelerCelY - vijandCelY) <= marge;
}

  toon() {
    image(this.animatie[this.frameNummer],this.x,this.y,raster.celGrootte,raster.celGrootte);
  }
}  

class Vijand {
  constructor(x,y) {
    this.x = x;
    this.y = y;
    this.sprite = null;
    this.stapGrootte = null;
  }

  beweeg() {
    this.x += floor(random(-1,2))*this.stapGrootte;
    this.y += floor(random(-1,2))*this.stapGrootte;

    this.x = constrain(this.x,0,canvas.width - raster.celGrootte);
    this.y = constrain(this.y,0,canvas.height - raster.celGrootte);
  }
  
  toon() {
    image(this.sprite,this.x,this.y,raster.celGrootte,raster.celGrootte);
  }
}

//Maak een klasse aan voor de appels
class Appel {
  constructor(x, y, color, isMoving) {
    this.x = x;
    this.y = y;
    this.color = color;
    this.isMoving = isMoving;
    this.isEaten = false;
    this.stapGrootteX = 0; 
    this.stapGrootteY = 0; 
  }

  beweeg() {
    if (this.isMoving && !this.isEaten) {
      this.x += this.stapGrootteX;
      this.y += this.stapGrootteY;

      // Van richting veranderen op borde
      if (this.x <= 0 || this.x >= canvas.width - raster.celGrootte) {
        this.stapGrootteX *= -1;
      }
      if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
        this.stapGrootteY *= -1;
      }
      
    this.x = constrain(this.x, 0, canvas.width - raster.celGrootte);
this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);

    }
  } 
    
toon(){  
if (!this.isEaten) {
image(this.sprite,this.x,this.y,raster.celGrootte,raster.celGrootte);
  }
}
resetPositie() {
  this.x = floor(random(0, raster.aantalKolommen)) * raster.celGrootte;
  this.y = floor(random(0, raster.aantalRijen)) * raster.celGrootte;
    this.isEaten = false; 
}    
}

//Klasse maken voor bommen
class Bom {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.stapGrootteY = random(25, 65);  // Willekeurige verticale snelheid
    this.richting = 1;  // Begin met naar beneden bewegen
    this.sprite = null;
  }

 beweeg() {
     // Beweeg verticaal op en neer met een unieke snelheid
    this.y += this.stapGrootteY * this.richting;

    // Wissel van richting wanneer de bom de boven- of onderkant raakt
    if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
        this.richting *= -1;  // Verander de richting
        this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
    }
}

  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}


let bommen = [];  // Lijst om de bommen in op te slaan
let startTijd;
let endTime = null;  // Voor het opslaan van de eindtijd
let spelBeeindigd = false; 

function keyPressed() {
  if (keyCode === 32 && spelBeeindigd) {  // Spatiebalk en alleen als spel is beëindigd
    spelBeeindigd = false;  
    setup();  // Start een nieuw spel
    loop();   // Start de game-loop opnieuw
  }
}

function setup() {
  bommen = []; // Lijst leegmaken 
  canvas = createCanvas(900,600);
  canvas.parent();
  frameRate(10);
  textFont("Verdana");
  
  raster = new Raster(12,18);
  raster.berekenCelGrootte();
  
  eve = new Jos();
  eve.stapGrootte = 1*raster.celGrootte;
  for (var b = 0;b < 6;b++) {
    frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }
  
  alice = new Vijand(700,200);
  alice.stapGrootte = 1*eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600,400);
  bob.stapGrootte = 1*eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");  
  
  // Appels op willekeurige posities genereren bij elk nieuw spel
  const randomRijRood = floor(random(0, raster.aantalRijen)) * raster.celGrootte;
  const randomKolomRood = floor(random(0, raster.aantalKolommen)) * raster.celGrootte;
  appelRood = new Appel(randomKolomRood, randomRijRood, 'red', false);
  appelRood.sprite = loadImage("images/sprites/overig/appel_2.png");

  const randomRijGroen = floor(random(0, raster.aantalRijen)) * raster.celGrootte;
  const randomKolomGroen = floor(random(0, raster.aantalKolommen)) * raster.celGrootte;
  appelGroen = new Appel(randomKolomGroen, randomRijGroen, 'green', true); // Moving apple
  appelGroen.sprite = loadImage("images/sprites/overig/appel_1.png");
  appelGroen.stapGrootteX = raster.celGrootte; // Set step size to match grid
  appelGroen.stapGrootteY = raster.celGrootte;
  
  startTijd = millis(); //starttijd vastleggen
   
  // Maak 5 bommen in willekeurige kolommen rechts van het midden
  for (let i = 0; i < 5; i++) {
    // Willekeurige kolom kiezen rechts van het midden (kolomindex > 5)
    let bomKolom = floor(random(10,raster.aantalKolommen)) * raster.celGrootte;
    // Willekeurige rij kiezen binnen het raster
    let bomRij = floor(random(0, raster.aantalRijen)) * raster.celGrootte;

    // Maak een nieuwe bom en voeg die toe aan de bommenlijst
    let bom = new Bom(bomKolom, bomRij);
    bom.sprite = loadImage("images/sprites/overig/bom_100px.png");
    bommen.push(bom);  // Voeg bom toe aan de lijst
  }
}

function draw() {
  background('lightblue');
  textAlign(LEFT);
  textSize(20);
  
  raster.teken();
  eve.beweeg();
  alice.beweeg();
  bob.beweeg();
  eve.toon();
  alice.toon();
  bob.toon();
  appelRood.toon();
  appelGroen.beweeg();
  appelGroen.toon();
  
  
    // Beweeg en toon alle bommen
  for (let i = 0; i < bommen.length; i++) {
    bommen[i].beweeg();
    bommen[i].toon();     
  }
  
  // Stopwatch functionaliteit
  let elapsedTime = millis() - startTijd;
  let seconds = floor(elapsedTime / 1000) % 60;
  let minutes = floor(elapsedTime / 1000 / 60);
  
   // Toon de timer rechtsbovenin
  fill('white');
  textSize(20); 
  text("Tijd: " + nf(minutes, 2) + ":" + nf(seconds, 2), width - 150, 30); 

    
 if (eve.x == appelRood.x && eve.y == appelRood.y && !appelRood.isEaten) {
    appelRood.isEaten = true;  // Rode appel als gegeten
    eve.levens += 1;  // Leven erbij als rode appel is gegeten
   appelRood.resetPositie(); // nieuwe plek spawnen als appel gegeten is
  }

  if (eve.x == appelGroen.x && eve.y == appelGroen.y && !appelGroen.isEaten) {
    appelGroen.isEaten = true;  // Groene appel gegeten
    eve.levens += 1;  // Leven erbij als groene appel is gegeten
    appelGroen.resetPositie(); // nieuwe plek spawnen als appel gegeten is
  }
  
// Leven eraf als speler wordt geraakt door vijand of bom
if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
  eve.levens -= 1;  // Leven eraf als speler wordt geraakt door vijand
}

// Botsing met een van de bommen controleren
for (let i = 0; i < bommen.length; i++) {
  if (eve.wordtGeraakt(bommen[i])) {
    eve.levens -= 1;
  }
}


  
  fill('darkblue');
  textSize(20); 
  text("Aantal levens: " + eve.levens, 30, 30); 
   
  if (eve.levens == 0) {
    background('red')
    fill('white')
    textSize(90);
    text('Je hebt verloren...', 30, 300)
// Instructie om opnieuw te starten, gecentreerd onderin
    textAlign(CENTER);
    textSize(20);
    text("Druk op spatiebalk om opnieuw te beginnen", width / 2, height - 30);
    spelBeeindigd = true;  // Markeer het spel als beëindigd
    noLoop();  // Stop de game-loop
  }
  
  if (eve.gehaald) {
    background('green');
    fill('white');
    textSize (90);
    text("Je hebt gewonnen!",30,300);
    
    if (endTime === null) {
      endTime = elapsedTime;  // Opslaan van eindtijd
    }

    // Toon de tijd die de speler nodig had om te winnen
    let winSeconds = floor(endTime / 1000) % 60;
    let winMinutes = floor(endTime / 1000 / 60);
    textSize(30);  // Kleiner lettertype voor de tijd
    text("Tijd: " + nf(winMinutes, 2) + ":" + nf(winSeconds, 2), 30, 400);
// Instructie om opnieuw te starten, gecentreerd onderin
    textAlign(CENTER);
    textSize(20);
    text("Druk op spatiebalk om opnieuw te beginnen", width / 2, height - 30);
    spelBeeindigd = true;
    noLoop();  // Stop de game-loop
  }
  
}